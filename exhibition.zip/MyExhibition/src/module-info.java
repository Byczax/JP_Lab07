module myexhibition {
	requires transitive exhibition;
	exports lab07;
}