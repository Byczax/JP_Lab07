package communication;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IDesigner extends Remote {
	// method for the monitor
	public void notify(int standId, boolean isConnected) throws RemoteException;
}
