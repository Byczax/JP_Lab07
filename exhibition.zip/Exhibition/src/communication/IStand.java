package communication;

import java.rmi.Remote;
import java.rmi.RemoteException;

import support.Description;

public interface IStand extends Remote {
	// methods for designers
	public void setContent(Description d) throws RemoteException;
	public int getId() throws RemoteException; 
}
