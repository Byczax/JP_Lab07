package communication;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IMonitor  extends Remote {
	// method for the center
	public void setScore(String userName, int percentageScore) throws RemoteException;
}
