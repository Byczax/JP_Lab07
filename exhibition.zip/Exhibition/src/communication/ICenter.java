package communication;

import java.rmi.Remote;
import java.rmi.RemoteException;

import support.Answer;
import support.CustomException;
import support.Question;


public interface ICenter extends Remote{
    // methods for visitors
	public int signIn(String visitorName) throws RemoteException;
	public void signOut(int visitorId) throws RemoteException, CustomException;
	public Question[] getQuestions() throws RemoteException;
    public boolean[] checkAnswers(int userId, Answer[] a) throws RemoteException, CustomException;
	
	// methods for designers
	public void addQA(Question[] q, Answer[] a) throws RemoteException, CustomException;
    IStand[] getStands() throws RemoteException;
    public int connect(IDesigner id) throws RemoteException;

    // method for stands
    public int connect(IStand is) throws RemoteException;
  
    // method for monitors
    public int connect(IMonitor im) throws RemoteException;

    // method for designers, stands and monitors
    public void disconnect(int identifier) throws RemoteException, CustomException;

}
