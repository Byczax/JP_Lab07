module exhibition {
	requires transitive java.rmi;
	exports communication;
	exports support;
}