package support;

import java.io.Serializable;

public class Answer implements Serializable {
	private static final long serialVersionUID = 1L;
	public String answer;
}
