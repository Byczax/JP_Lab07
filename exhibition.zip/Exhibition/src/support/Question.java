package support;

import java.io.Serializable;

public class Question implements Serializable {
	private static final long serialVersionUID = 1L;
	public String question;
}
